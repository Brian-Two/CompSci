#ifndef FILEUTIL_H_INCLUDED
#define FILEUTIL_H_INCLUDED

#include <string>

std::string getFileContents(const std::string &filePath);

#endif // FILEUTIL_H_INCLUDED
