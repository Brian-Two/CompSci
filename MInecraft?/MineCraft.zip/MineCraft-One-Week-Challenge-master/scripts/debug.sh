sh scripts/build.sh
gdb ./bin/debug/mc-one-week
