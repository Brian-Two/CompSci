# CompSci
This extension allows you to view the social media pages of Bergen County Academies! 

In order to use the program you have to 
    1. Go to your extension settings on google.
    2. Turn on Developer mode.
    3. Select - "load unpacked", then select this file.
    4. You will now be able to access it in your extensions settings or on the top right of your browser. 
