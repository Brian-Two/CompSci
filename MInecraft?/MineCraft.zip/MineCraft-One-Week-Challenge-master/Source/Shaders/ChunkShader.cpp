#include "ChunkShader.h"

ChunkShader::ChunkShader()
    : BasicShader("Chunk", "Chunk")
{
    getUniforms();
}

void ChunkShader::getUniforms()
{
    BasicShader::getUniforms();
}
